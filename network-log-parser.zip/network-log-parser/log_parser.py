import re
from collections import defaultdict
from datetime import datetime

LOG_FILE = "sample_log.txt"

ANOMALY_KEYWORDS = [
    "timeout", "unauthorized", "failed",
    "high latency", "packet loss", "threshold exceeded"
]

def parse_log_line(line):
    pattern = r"(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}) (\w+)\s+([\d.]+)\s+(.*)"
    match = re.match(pattern, line.strip())
    if match:
        timestamp, level, ip, message = match.groups()
        return {
            "timestamp": datetime.strptime(timestamp, "%Y-%m-%d %H:%M:%S"),
            "level": level,
            "ip": ip,
            "message": message
        }
    return None

def is_anomaly(message):
    return any(kw in message.lower() for kw in ANOMALY_KEYWORDS)

def analyze_logs(filepath):
    entries = []
    anomalies = []
    level_counts = defaultdict(int)
    ip_counts = defaultdict(int)

    with open(filepath, "r") as f:
        for line in f:
            entry = parse_log_line(line)
            if not entry:
                continue
            entries.append(entry)
            level_counts[entry["level"]] += 1
            ip_counts[entry["ip"]] += 1
            if is_anomaly(entry["message"]) or entry["level"] == "ERROR":
                anomalies.append(entry)

    return entries, anomalies, level_counts, ip_counts

def print_report(entries, anomalies, level_counts, ip_counts):
    print("=" * 50)
    print("  NETWORK LOG ANALYSIS REPORT")
    print("=" * 50)
    print(f"\nTotal entries parsed : {len(entries)}")
    print(f"Anomalies detected   : {len(anomalies)}")
    print(f"Triage reduction     : ~{round((1 - len(anomalies)/len(entries)) * 100)}% noise filtered\n")

    print("Event breakdown:")
    for level, count in sorted(level_counts.items()):
        print(f"  {level:<8} {count}")

    print("\nTop IPs by activity:")
    for ip, count in sorted(ip_counts.items(), key=lambda x: -x[1])[:5]:
        print(f"  {ip:<18} {count} events")

    print("\nAnomalies flagged:")
    for a in anomalies:
        ts = a["timestamp"].strftime("%Y-%m-%d %H:%M:%S")
        print(f"  [{a['level']}] {ts} | {a['ip']} | {a['message']}")

    print("\n" + "=" * 50)

if __name__ == "__main__":
    entries, anomalies, level_counts, ip_counts = analyze_logs(LOG_FILE)
    print_report(entries, anomalies, level_counts, ip_counts)
